# 32 Contracts

**Project:** MATTERMOST
**Upstream:** https://github.com/mattermost/mattermost

Content specific to MATTERMOST in category CHAT_PLATFORMS.
